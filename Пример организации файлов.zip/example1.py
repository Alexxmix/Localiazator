import localizator

localizator.setWorkSpace('rus')
localizator.setDefaultForm('ИпЕд')

print('Вы получили {}'.format(localizator.wordForm('Water', 'ВпЕд'))) #Файл есть и полностью заполнен
print('Вы получили {}'.format(localizator.wordForm('Grass', 'ВпЕд'))) #В файле присутствуе только стандартная форма
print('Вы получили {}'.format(localizator.wordForm('Cloud', 'ВпЕд'))) #В файле нет никаких форм
print('Вы получили {}'.format(localizator.wordForm('Bottle', 'ВпЕд'))) #Файла не с названием, как у объекта не существует
